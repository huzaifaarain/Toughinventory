#
# TABLE STRUCTURE FOR: company_details
#

DROP TABLE IF EXISTS company_details;

CREATE TABLE `company_details` (
  `company_name` varchar(1000) NOT NULL,
  `owner_name` varchar(1000) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `city` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO company_details (`company_name`, `owner_name`, `address`, `city`, `contact`, `email`) VALUES ('Demo Company', 'Demo Owner', 'City , ABC Town', 'Dadu', '+123-123-123', 'info@divsnpixel.com');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) CHARACTER SET utf8 NOT NULL,
  `company` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `obalance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO customers (`id`, `name`, `company`, `address`, `phone`, `email`, `obalance`) VALUES (10, 'ADIL', '', '', '', '', '3000');
INSERT INTO customers (`id`, `name`, `company`, `address`, `phone`, `email`, `obalance`) VALUES (11, 'Customer', '', '', '', '', '0');
INSERT INTO customers (`id`, `name`, `company`, `address`, `phone`, `email`, `obalance`) VALUES (12, 'Umair Jawaid', '', '', '', '', '0');


#
# TABLE STRUCTURE FOR: p_payments
#

DROP TABLE IF EXISTS p_payments;

CREATE TABLE `p_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `reference_po` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET latin1 DEFAULT NULL,
  `amount` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `p_payments_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO p_payments (`id`, `supplier_id`, `reference_po`, `date`, `note`, `amount`) VALUES (6, 4, '7', '2015-02-02', '', '12000.00');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(255) CHARACTER SET utf8 NOT NULL,
  `unit` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `ostockq` double NOT NULL DEFAULT '0',
  `ostockamount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (1, 'Processor', 'CTN', 240, '2200.00', '2280.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (2, 'Keyboard', 'CTN', 120, '400.00', '500.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (3, 'Mouse', 'CTN', 50, '150.00', '250.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (4, 'LCD', 'CTN', 0, '4500.00', '4600.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (5, 'Printer', '', 0, '6000.00', '7000.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (6, 'Ethernet Cables', '', 0, '500.00', '600.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (7, 'HDMI Cables', '', 0, '120.00', '160.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (8, 'Flashdrive', '', 0, '1600.00', '1800.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (9, 'RAM DDRII 1GB', '', 0, '1200.00', '1600.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (10, 'RAM DDRII 2GB', '', 0, '1600.00', '1900.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (11, 'Motherboard 1-xxx', '', 0, '12000.00', '15000.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (12, 'Speaker', '', 0, '600.00', '700.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (13, 'Laptop P.Adapter', '', 0, '1500.00', '1600.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (14, 'Power Cables', '', 0, '1200.00', '1300.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (15, 'CPU Fan', '', 0, '350.00', '450.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (16, 'Power Supply', '', 0, '960.00', '1000.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (17, 'Web Cam', '', 0, '1500.00', '1800.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (18, 'Blank Dics', '', 0, '30.00', '50.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (19, 'Ethernet Router', '', 0, '2500.00', '2800.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (20, 'NVidia G.Card 128MB', '', 0, '2500.00', '2600.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (21, 'ATI Radeon G 512MB', '', 0, '3600.00', '3800.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (22, 'Dell 280 CPU', '', 0, '16000.00', '18000.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (23, 'Dell L.D630', '', 0, '23000.00', '26000.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (24, 'HP P.98', '', 0, '18000.00', '20000.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (25, 'HP Deskjet', '', 0, '4600.00', '5800.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (26, 'VGA MM Cable', '', 0, '1000.00', '1400.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (27, 'USB-VGA Adapter', '', 0, '4000.00', '4800.00', 0, '0', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (28, 'Audionic MAX-5U', '-', 0, '2350.00', '2400.00', 0, '0', '0');


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`),
  KEY `purchase_id_2` (`purchase_id`),
  CONSTRAINT `purchase_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchase_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (51, 7, 1, '10', '2200.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (52, 7, 2, '10', '400.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (55, 8, 28, '6', '2325.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (56, 9, 1, '10', '2200.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (57, 9, 2, '12', '400.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (58, 9, 3, '16', '150.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (59, 10, 9, '10', '1200.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (60, 10, 10, '12', '1600.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (61, 10, 25, '14', '4600.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (62, 10, 26, '16', '1000.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (63, 10, 11, '18', '12000.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (64, 10, 27, '20', '4000.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (65, 10, 12, '22', '600.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (66, 10, 13, '24', '1500.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (67, 10, 14, '26', '1200.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (68, 10, 15, '28', '350.00');


#
# TABLE STRUCTURE FOR: purchaser_items
#

DROP TABLE IF EXISTS purchaser_items;

CREATE TABLE `purchaser_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `unit_price` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`),
  KEY `purchase_id_2` (`purchase_id`),
  CONSTRAINT `purchaser_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases_r` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchaser_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO purchaser_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (1, 1, 3, '2', '150');


#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `tax_per` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `supplier_id_2` (`supplier_id`),
  CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO purchases (`id`, `reference_no`, `supplier_id`, `date`, `note`, `tax_per`) VALUES (7, '', 4, '2015-02-01', '', 0);
INSERT INTO purchases (`id`, `reference_no`, `supplier_id`, `date`, `note`, `tax_per`) VALUES (8, '', 4, '2015-02-03', '', 0);
INSERT INTO purchases (`id`, `reference_no`, `supplier_id`, `date`, `note`, `tax_per`) VALUES (9, '', 4, '2015-08-29', '', 0);
INSERT INTO purchases (`id`, `reference_no`, `supplier_id`, `date`, `note`, `tax_per`) VALUES (10, '', 4, '2015-08-29', '', 0);


#
# TABLE STRUCTURE FOR: purchases_r
#

DROP TABLE IF EXISTS purchases_r;

CREATE TABLE `purchases_r` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `supplier_id_2` (`supplier_id`),
  CONSTRAINT `purchases_r_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO purchases_r (`id`, `reference_no`, `supplier_id`, `date`, `note`, `total_tax`) VALUES (1, '', 4, '2015-02-20', '', '0.00');


#
# TABLE STRUCTURE FOR: rp_setting
#

DROP TABLE IF EXISTS rp_setting;

CREATE TABLE `rp_setting` (
  `header` longtext,
  `footer` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO rp_setting (`header`, `footer`) VALUES ('<table style=\"width: 100%;\">\r\n<tbody>\r\n<tr>\r\n<td style=\"text-align: center;\" colspan=\"3\">\r\n<h4 style=\"font-size: 28px !important;\">Inspire Computers</h4>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>&nbsp;Address :&nbsp;<strong>City , ABC Town</strong></td>\r\n<td>Contact :&nbsp;<strong>+123-123-123</strong></td>\r\n<td>Email -&nbsp;<strong>info@divsnpixel.com</strong></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<hr />', '<p style=\"text-align: center;\"><strong>THIS IS SOFTWARE GENERATED DOCUMENT .&nbsp;</strong></p>');


#
# TABLE STRUCTURE FOR: s_payments
#

DROP TABLE IF EXISTS s_payments;

CREATE TABLE `s_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `reference_so` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET latin1 DEFAULT NULL,
  `amount` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `s_payments_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO s_payments (`id`, `customer_id`, `reference_so`, `date`, `note`, `amount`) VALUES (7, 10, '', '2015-02-02', '', '1000.00');
INSERT INTO s_payments (`id`, `customer_id`, `reference_so`, `date`, `note`, `amount`) VALUES (8, 11, '', '2015-02-05', '', '2280.00');


#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `scheme` decimal(25,2) DEFAULT '0.00',
  `comission` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `quantity`, `unit_price`, `scheme`, `comission`) VALUES (87, 19, 1, '1', '2280.00', '0.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `quantity`, `unit_price`, `scheme`, `comission`) VALUES (88, 18, 2, '1', '500.00', '15.00', '15.00');


#
# TABLE STRUCTURE FOR: saler_items
#

DROP TABLE IF EXISTS saler_items;

CREATE TABLE `saler_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `saler_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales_r` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `saler_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO saler_items (`id`, `sale_id`, `product_id`, `quantity`) VALUES (1, 1, 2, '2');


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO sales (`id`, `reference_no`, `customer_id`, `date`, `note`, `total_tax`) VALUES (18, '', 10, '2015-02-01', '', '2.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `date`, `note`, `total_tax`) VALUES (19, '', 11, '2015-02-05', '', '0.00');


#
# TABLE STRUCTURE FOR: sales_r
#

DROP TABLE IF EXISTS sales_r;

CREATE TABLE `sales_r` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `sales_r_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO sales_r (`id`, `reference_no`, `customer_id`, `date`, `note`) VALUES (1, '', 12, '2015-02-12', '');


#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) CHARACTER SET utf8 NOT NULL,
  `company` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `obalance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO suppliers (`id`, `name`, `company`, `address`, `phone`, `email`, `obalance`) VALUES (4, 'M.A Computer', '', '', '', '', '75000');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8 NOT NULL,
  `password` varchar(40) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `first_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `last_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO users (`id`, `username`, `password`, `email`, `first_name`, `last_name`) VALUES (1, 'admin', '&*^Divs&*^Pixel&*^', 'abc@abc.com', 'Demo User', 'Demo');
INSERT INTO users (`id`, `username`, `password`, `email`, `first_name`, `last_name`) VALUES (2, 'admin', 'admin', 'abc@abc.com', 'Demo User', 'Demo');


