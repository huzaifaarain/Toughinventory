#
# TABLE STRUCTURE FOR: company_details
#

DROP TABLE IF EXISTS company_details;

CREATE TABLE `company_details` (
  `company_name` varchar(1000) NOT NULL,
  `owner_name` varchar(1000) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `city` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO company_details (`company_name`, `owner_name`, `address`, `city`, `contact`, `email`) VALUES ('Bhittai Poultry', 'Haji Ghulam Mustafa Brohi', 'City , ABC Town', 'Dadu', '+123-123-123', 'info@divsnpixel.com');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) CHARACTER SET utf8 NOT NULL,
  `company` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `obalance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO customers (`id`, `name`, `company`, `address`, `phone`, `email`, `obalance`) VALUES (3, 'Huzaifa Arain', 'Software House', 'Hyderabad', '+923342550219', 'huzaifa.itgroup@gmail.com', '25000');
INSERT INTO customers (`id`, `name`, `company`, `address`, `phone`, `email`, `obalance`) VALUES (4, 'Umair Jawaid', '', '', '', '', '3200');


#
# TABLE STRUCTURE FOR: p_payments
#

DROP TABLE IF EXISTS p_payments;

CREATE TABLE `p_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `reference_po` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET latin1 DEFAULT NULL,
  `amount` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `p_payments_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO p_payments (`id`, `supplier_id`, `reference_po`, `date`, `note`, `amount`) VALUES (1, 1, '', '2015-01-01', '', '30000.00');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(255) CHARACTER SET utf8 NOT NULL,
  `unit` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `ostockq` double NOT NULL DEFAULT '0',
  `ostockamount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (1, 'Chenak 17gm', 'CTN', 240, '2200.00', '2280.00', 0, '25', '0');
INSERT INTO products (`id`, `name`, `unit`, `size`, `cost`, `price`, `alert_quantity`, `ostockq`, `ostockamount`) VALUES (2, 'Chenak 95gm', 'CTN', 120, '5000.00', '6000.00', 0, '0', '0');


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`),
  KEY `purchase_id_2` (`purchase_id`),
  CONSTRAINT `purchase_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchase_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (1, 1, 1, '25', '2200.00');
INSERT INTO purchase_items (`id`, `purchase_id`, `product_id`, `quantity`, `unit_price`) VALUES (2, 1, 2, '36', '5000.00');


#
# TABLE STRUCTURE FOR: purchaser_items
#

DROP TABLE IF EXISTS purchaser_items;

CREATE TABLE `purchaser_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `unit_price` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`),
  KEY `purchase_id_2` (`purchase_id`),
  CONSTRAINT `purchaser_items_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchases_r` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchaser_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `tax_per` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `supplier_id_2` (`supplier_id`),
  CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO purchases (`id`, `reference_no`, `supplier_id`, `date`, `note`, `tax_per`) VALUES (1, '', 1, '2015-01-01', '', 0);


#
# TABLE STRUCTURE FOR: purchases_r
#

DROP TABLE IF EXISTS purchases_r;

CREATE TABLE `purchases_r` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `supplier_id_2` (`supplier_id`),
  CONSTRAINT `purchases_r_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: rp_setting
#

DROP TABLE IF EXISTS rp_setting;

CREATE TABLE `rp_setting` (
  `header` longtext,
  `footer` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO rp_setting (`header`, `footer`) VALUES ('<p class=\"text-center\">Raheel KK</p>', '<p style=\"text-align: center;\"><strong>THIS IS SOFTWARE GENERATED DOCUMENT .&nbsp;</strong></p>');


#
# TABLE STRUCTURE FOR: s_payments
#

DROP TABLE IF EXISTS s_payments;

CREATE TABLE `s_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `reference_so` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET latin1 DEFAULT NULL,
  `amount` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `s_payments_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `scheme` decimal(25,2) DEFAULT '0.00',
  `comission` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `quantity`, `unit_price`, `scheme`, `comission`) VALUES (1, 1, 1, '2', '2280.00', '10.00', '300.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `quantity`, `unit_price`, `scheme`, `comission`) VALUES (2, 2, 1, '1', '2280.00', '-100.00', '0.00');


#
# TABLE STRUCTURE FOR: saler_items
#

DROP TABLE IF EXISTS saler_items;

CREATE TABLE `saler_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `saler_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales_r` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `saler_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO sales (`id`, `reference_no`, `customer_id`, `date`, `note`, `total_tax`) VALUES (1, '', 3, '2015-01-01', '', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `date`, `note`, `total_tax`) VALUES (2, '', 3, '2015-01-08', '', '0.00');


#
# TABLE STRUCTURE FOR: sales_r
#

DROP TABLE IF EXISTS sales_r;

CREATE TABLE `sales_r` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) CHARACTER SET utf8 NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `sales_r_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) CHARACTER SET utf8 NOT NULL,
  `company` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `obalance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO suppliers (`id`, `name`, `company`, `address`, `phone`, `email`, `obalance`) VALUES (1, 'Huzaifa Arain', 'Software House', 'Hyderabad', '+923342550219', 'huzaifa.itgroup@gmail.com', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8 NOT NULL,
  `password` varchar(40) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `first_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `last_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO users (`id`, `username`, `password`, `email`, `first_name`, `last_name`) VALUES (1, 'admin', '&*^Divs&*^Pixel&*^', 'abc@abc.com', 'Demo User', 'Demo');
INSERT INTO users (`id`, `username`, `password`, `email`, `first_name`, `last_name`) VALUES (2, 'admin', 'admin', 'abc@abc.com', 'Demo User', 'Demo');


