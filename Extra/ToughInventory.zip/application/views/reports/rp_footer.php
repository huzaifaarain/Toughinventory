<?php $header = $this->dbo->rp_getSetting('footer'); ?>
<div class="row-fluid">
	<div class="span12">
		<?php echo (isset($header->footer) ? $header->footer : null); ?>
	</div>
</div>
<div class="row-fluid">
   <div class="span12">
      <p class="text-center">Tough Logic Powered By Divs & Pixel. www.divsnpixel.com - +92-306-038-3210</p>
   </div>
</div>