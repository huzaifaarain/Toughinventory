<?php 
    $stockvalue = $this->dbo->stockvalue();
 ?>
<div id="container" class="row-fluid">
<?php $this->load->view('sidebar'); ?>
<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                 <h3 class="page-title">
                     Dashboard
                   </h3>
                   <?php $this->load->view('msg'); ?>
                    <div class="row-fluid">
                     <div class="span12">
                         <div class="widget yellow">
                        <div class="widget-title">
                            <h4><i class="icon-calendar"></i><?php echo date("M-Y"); ?> Average</h4>
                            <span class="tools">
                                <a href="javascript:;" class="icon-chevron-down"></a>
                            </span>
                        </div>
                        <div class="widget-body">
                            <div style="min-height:1200px;" id="currentMonthChart"></div>
                        </div>
                    </div>
                     </div>
                   </div>
                   <div class="row-fluid">
                     <div class="span4">
                       <div id="stockAmountChart"></div>
                     </div>
                     <div class="span4">
                     <div id="stockledgerChart"></div>
                     </div>
                     <div class="span4">
                     <div id="outStanding"></div>
                     </div>
                   </div>
                  
               </div>
            </div>
        </div>
</div>
</div>
<?php $this->load->view('scripts'); ?>
<script type="text/javascript">
  $(function(){
    // ready

    $('#stockAmountChart').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: 1,//null,
            plotShadow: false
        },
         credits: {
            enabled: false
        },
        title: {
            text: 'Stock Value By Cost and Price'
        },
        series: [{
            type: 'pie',
            name: 'Stock Values',
            data: [
                ['By Cost',   <?php echo $stockvalue->row()->bycost; ?>],
                {
                    name: 'By Price',
                    y: <?php echo $stockvalue->row()->byprice; ?>,
                    sliced: true,
                    selected: true
                }
            ]
        }]
    });

    $('#stockledgerChart').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: 1,//null,
            plotShadow: false
        },
         credits: {
            enabled: false
        },
        title: {
            text: 'Recent Stock Status'
        },
        series: [{
            type: 'pie',
            name: 'Available Quantity',
            data: [
                <?php $x=1; foreach ($slchart->result() as $rows) {
          ?>
          
            [  '<?php echo $rows->Name; ?>',
            <?php echo $rows->Avail; ?>]<?php echo (($x == $slchart->num_rows()) ? null : ","); ?>
          <?php
        $x=1; } ?>
            ]
        }]
    });

     $('#outStanding').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: 1,//null,
            plotShadow: false
        },
         credits: {
            enabled: false
        },
        title: {
            text: 'High Amount Customers'
        },
        series: [{
            type: 'pie',
            name: 'Outstanding Status',
            data: [
            <?php $y = 1; foreach ($highCustomers->result() as $customer) 
            {
              ?> [<?php echo "'.$customer->Name.'"; ?>,<?php echo $customer->Balance; ?>]<?php echo (($y == $highCustomers->num_rows()) ? null : "," );
            $y++;} ?>
            ]
        }]
    });

     $('#currentMonthChart').highcharts({
        chart: {
            type: 'bar'
        },
        title: {
            text: '<?php echo date("M-Y"); ?> Average'
        },
        subtitle: {
            text: 'Estimated Statistics'
        },
        xAxis: {
            categories: [
                <?php for ($i = 1; $i <= date('t'); $i++) {
                  ?>
                  '<?php echo date($i."-M"); ?>'<?php echo (($i == date('t')) ? null : ","); ?>
                  <?php
                }; ?>
            ]
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Amount (PKR)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.1f} PKR</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [{
            name: 'Purchase',
            data: [
            <?php for ($i=0; $i < count($purchaseArray) ; $i++) { echo $purchaseArray[$i].(($i==count($purchaseArray)-1) ? null : ","); } ?>
            ]

        }, {
            name: 'Sale',
            data: [
            <?php for ($i=0; $i < count($saleArray) ; $i++) { echo $saleArray[$i].(($i==count($saleArray)-1) ? null : ","); } ?>
            ]

        }, {
            name: 'Amount Paid(Purchase Amount)',
            data: [
            <?php for ($i=0; $i < count($pPaidArray) ; $i++) { echo $pPaidArray[$i].(($i==count($pPaidArray)-1) ? null : ","); } ?>
            ]

        }, {
            name: 'Amount Received(Sale Amount)',
           data: [
            <?php for ($i=0; $i < count($sRecArray) ; $i++) { echo $sRecArray[$i].(($i==count($sRecArray)-1) ? null : ","); } ?>
            ]

        }]
    });

   
    // end of ready
  });
</script>